
-- --------------------------------------------------------

--
-- Struttura della tabella `Home`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Home`;
CREATE TABLE IF NOT EXISTS `Home` (
  `home_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `address_home` varchar(50) DEFAULT NULL,
  `name_home` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`home_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Home`
--

INSERT DELAYED IGNORE INTO `Home` (`home_id`, `address_home`, `name_home`) VALUES
(1, 'via catania 1', 'il b&b'),
(2, 'piazza Italia 209', 'la casa storica'),
(3, 'via Federico 18', 'Fede b&b');
