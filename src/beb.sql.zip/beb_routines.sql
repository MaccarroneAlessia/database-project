
DELIMITER $$
--
-- Procedure
--
DROP PROCEDURE IF EXISTS `calculate_cost_invoice`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `calculate_cost_invoice` (IN `new_invoice_id` INT)   BEGIN
    UPDATE Invoice i
    INNER JOIN Request r ON i.reservation_id = r.reservation_id
    INNER JOIN Reservation re ON r.reservation_id = re.reservation_id 
    INNER JOIN Customer c ON re.customer_id = c.customer_id
    SET i.amount = r.cost * re.num_people * i.rate - c.points
    WHERE i.invoice_number = new_invoice_id;
END$$

DROP PROCEDURE IF EXISTS `calculate_cost_request`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `calculate_cost_request` (IN `new_request_id` INT)   BEGIN
    DECLARE costocamere FLOAT;
    DECLARE costoservizi FLOAT;
    DECLARE numgiorni FLOAT;

    SELECT DISTINCT SUM(Ro.rate), SUM(Se.rate), SUM(DATEDIFF(So.date_fin, So.date_in)) INTO costocamere, costoservizi, numgiorni
    FROM Request Re, Room Ro, Selection S, Servicing Se, Sojourn So
    WHERE Re.request_id = new_request_id AND S.request_id = Re.request_id AND S.room_id = Ro.room_id AND S.service_id = Se.service_id AND Re.sojourn_id = So.sojourn_id
    GROUP BY Re.request_id;

    UPDATE Request R
    SET R.cost = (costocamere + costoservizi) * numgiorni
    WHERE R.request_id = new_request_id;
END$$

DROP PROCEDURE IF EXISTS `op1`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op1` (IN `num` INT, IN `client` INT)   BEGIN
    INSERT INTO Reservation(num_people, customer_id) VALUES (num, client);
END$$

DROP PROCEDURE IF EXISTS `op10`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op10` (IN `id` INT)   BEGIN
    UPDATE Customer
    SET points = points + 5
    WHERE customer_id = id;
END$$

DROP PROCEDURE IF EXISTS `op11`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op11` (IN `id` INT)   BEGIN
    SELECT points
    FROM Customer C
    WHERE customer_id = id;
END$$

DROP PROCEDURE IF EXISTS `op12`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op12` (IN `id` INT)   BEGIN
    SELECT customer_id, num_stars, comment
    FROM Review R
    WHERE room_id = id;
END$$

DROP PROCEDURE IF EXISTS `op13`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op13` (IN `idS` INT, IN `idR` INT)   BEGIN
    INSERT INTO Report(report_id, collections, staff_id) 
    SELECT idR, SUM(amount), idS
    FROM Invoice I 
    WHERE report_id = NULL;
    
    UPDATE Invoice
    SET report_id = idR
    WHERE report_id = NULL;
END$$

DROP PROCEDURE IF EXISTS `op14`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op14` (IN `addr` VARCHAR(50), IN `n` VARCHAR(30))   BEGIN
   INSERT INTO Home(address_home, name_home)
   VALUES (addr, n);
END$$

DROP PROCEDURE IF EXISTS `op2`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op2` (IN `data_i` DATE, IN `data_f` DATE, IN `id` INT)   BEGIN
    UPDATE Sojourn 
    SET date_in = data_i AND date_fin = data_f
    WHERE sojourn_id = id;
END$$

DROP PROCEDURE IF EXISTS `op3`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op3` (IN `id` INT)   BEGIN
    DELETE 
    FROM Reservation 
    WHERE reservation_id = id;
END$$

DROP PROCEDURE IF EXISTS `op4`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op4` (IN `id` INT)   BEGIN
    SELECT *
    FROM Reservation R, Customer C, Request Re
    WHERE R.customer_id = C.customer_id AND C.customer_id = id AND R.reservation_id = Re.reservation_id;
END$$

DROP PROCEDURE IF EXISTS `op5`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op5` (IN `id` INT)   BEGIN
    SELECT R.reservation_id, SUM(cost) AS CostoTotale
    FROM Reservation R, Request Re
    WHERE R.reservation_id = Re.reservation_id AND R.reservation_id = id
    GROUP BY R.reservation_id;
END$$

DROP PROCEDURE IF EXISTS `op6`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op6` (IN `id` INT)   BEGIN
    SELECT *
    FROM Reservation R, Customer C, Request Re, Sojourn S, Selection Se, Servicing Ser, Room Ro
    WHERE R.customer_id = C.customer_id AND C.customer_id = id AND R.reservation_id = Re.reservation_id AND Re.sojourn_id = S.sojourn_id AND Se.request_id = Re.request_id AND Ser.service_id = Se.service_id AND Ro.room_id = Se.room_id;
END$$

DROP PROCEDURE IF EXISTS `op7`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op7` (IN `id` INT)   BEGIN
    SELECT *
    FROM Request Re, Reservation R, Sojourn S, Customer C
    WHERE R.reservation_id = Re.reservation_id AND R.customer_id = C.customer_id AND Re.sojourn_id = S.sojourn_id;
END$$

DROP PROCEDURE IF EXISTS `op8`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op8` (IN `id` INT)   BEGIN
    SELECT date_in, date_fin
    FROM Reservation R, Sojourn S
    WHERE R.sojourn_id = S.sojourn_id AND R.reservation_id = id;
END$$

DROP PROCEDURE IF EXISTS `op9`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `op9` (IN `id` INT)   BEGIN
    SELECT availability_room
    FROM Room R
    WHERE room_id = id;
END$$

DROP PROCEDURE IF EXISTS `P_Soggiorno`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `P_Soggiorno` (IN `sojourn_id` INT)   BEGIN
    DECLARE inizio INT;
    DECLARE stagione INT;

    SELECT MONTH(S.date_in) INTO inizio
    FROM Sojourn S
    WHERE S.sojourn_id = sojourn_id;

    SELECT season_id INTO stagione
    FROM Season Se
    WHERE Se.month_ = inizio;

    UPDATE Sojourn S
    SET S.season_id = stagione
    WHERE S.sojourn_id = sojourn_id;
END$$

DELIMITER ;
