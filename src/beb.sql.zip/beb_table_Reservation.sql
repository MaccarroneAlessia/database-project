
-- --------------------------------------------------------

--
-- Struttura della tabella `Reservation`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Reservation`;
CREATE TABLE IF NOT EXISTS `Reservation` (
  `reservation_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `date_` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `num_people` int UNSIGNED DEFAULT NULL,
  `customer_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Reservation`
--

INSERT DELAYED IGNORE INTO `Reservation` (`reservation_id`, `date_`, `num_people`, `customer_id`) VALUES
(1, '2023-03-04 14:14:08', 1, 1),
(2, '2023-03-04 14:14:08', 2, 2),
(3, '2023-03-04 14:14:08', 1, 3),
(4, '2023-03-04 14:14:08', 1, 4),
(5, '2023-03-04 14:14:08', 1, 5);
