
-- --------------------------------------------------------

--
-- Struttura della tabella `Request`
--
-- Creazione: Mar 04, 2023 alle 14:13
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Request`;
CREATE TABLE IF NOT EXISTS `Request` (
  `request_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `notes` text,
  `cost` float DEFAULT '0',
  `reservation_id` int UNSIGNED DEFAULT NULL,
  `sojourn_id` int UNSIGNED DEFAULT NULL,
  `staff_id` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `reservation_id` (`reservation_id`),
  KEY `sojourn_id` (`sojourn_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Request`
--

INSERT DELAYED IGNORE INTO `Request` (`request_id`, `notes`, `cost`, `reservation_id`, `sojourn_id`, `staff_id`) VALUES
(1, NULL, 50, 1, 1, 'ffvsrtgsthb'),
(2, NULL, 0, 2, 2, 'vererwfa'),
(3, NULL, 0, 3, 3, 'rvbtrnyjge'),
(4, NULL, 0, 4, 4, 'ffvsrtgsthb'),
(5, NULL, 0, 5, 5, 'vererwfa');
