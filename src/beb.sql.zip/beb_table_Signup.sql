
-- --------------------------------------------------------

--
-- Struttura della tabella `Signup`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Signup`;
CREATE TABLE IF NOT EXISTS `Signup` (
  `customer_id` int UNSIGNED NOT NULL,
  `home_id` int UNSIGNED NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`customer_id`,`home_id`),
  KEY `home_id` (`home_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Signup`
--

INSERT DELAYED IGNORE INTO `Signup` (`customer_id`, `home_id`, `password`) VALUES
(1, 1, NULL),
(2, 2, NULL),
(3, 3, NULL);

--
-- Trigger `Signup`
--
DROP TRIGGER IF EXISTS `T_tessera`;
DELIMITER $$
CREATE TRIGGER `T_tessera` AFTER INSERT ON `Signup` FOR EACH ROW BEGIN 
    UPDATE Customer C
    SET C.num_card = RAND()
    WHERE C.customer_id = new.customer_id;
END
$$
DELIMITER ;
