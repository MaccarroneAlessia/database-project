
-- --------------------------------------------------------

--
-- Struttura della tabella `Servicing`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Servicing`;
CREATE TABLE IF NOT EXISTS `Servicing` (
  `service_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `description_service` text,
  `rate` float UNSIGNED NOT NULL DEFAULT '0',
  `home_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`service_id`),
  KEY `home_id` (`home_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Servicing`
--

INSERT DELAYED IGNORE INTO `Servicing` (`service_id`, `description_service`, `rate`, `home_id`) VALUES
(1, 'parcheggio', 5, 1),
(2, 'piscina', 10, 2),
(3, 'cucina', 5, 3);
