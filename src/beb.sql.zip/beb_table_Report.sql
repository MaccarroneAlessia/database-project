
-- --------------------------------------------------------

--
-- Struttura della tabella `Report`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Report`;
CREATE TABLE IF NOT EXISTS `Report` (
  `report_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `curr_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `collections` float NOT NULL,
  `staff_id` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Report`
--

INSERT DELAYED IGNORE INTO `Report` (`report_id`, `curr_date`, `collections`, `staff_id`) VALUES
(1, '2023-03-04 14:14:08', 0, 'adcsewe'),
(2, '2023-03-04 14:14:08', 0, 'bge6ye5bngds'),
(3, '2023-03-04 14:14:08', 0, 'vtevberthr');
