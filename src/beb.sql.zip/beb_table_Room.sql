
-- --------------------------------------------------------

--
-- Struttura della tabella `Room`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Room`;
CREATE TABLE IF NOT EXISTS `Room` (
  `room_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name_room` varchar(30) DEFAULT NULL,
  `type_room` varchar(50) DEFAULT NULL,
  `description_room` text,
  `rate` float UNSIGNED NOT NULL DEFAULT '0',
  `availability_room` tinyint(1) NOT NULL DEFAULT '0',
  `home_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  KEY `home_id` (`home_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Room`
--

INSERT DELAYED IGNORE INTO `Room` (`room_id`, `name_room`, `type_room`, `description_room`, `rate`, `availability_room`, `home_id`) VALUES
(1, 'camera Deluxe', 'camera singola', NULL, 40, 0, 1),
(2, 'camera Queen', 'camera doppia', NULL, 50, 0, 1),
(3, 'camera Matrimoniale standard', 'matrimoniale', NULL, 70, 0, 2),
(4, 'camera familiare standard', 'tripla', NULL, 100, 0, 2),
(5, 'camera con vista oceano', 'doppia uso singola', NULL, 80, 0, 3),
(6, 'Suite King Deluxe', 'camera singola', NULL, 40, 0, 3),
(7, 'Suite master', 'camera quafrupla', NULL, 100, 0, 1),
(8, 'camera love', 'matrimoniale', NULL, 50, 0, 2),
(9, 'camera bimbi', 'camera tripla', NULL, 90, 0, 3);
