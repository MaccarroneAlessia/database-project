
-- --------------------------------------------------------

--
-- Struttura della tabella `PrivateService`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `PrivateService`;
CREATE TABLE IF NOT EXISTS `PrivateService` (
  `private_service_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `rate` float UNSIGNED DEFAULT '0',
  `description_service` text,
  `room_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`private_service_id`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `PrivateService`
--

INSERT DELAYED IGNORE INTO `PrivateService` (`private_service_id`, `rate`, `description_service`, `room_id`) VALUES
(1, 5, NULL, 3),
(2, 10, NULL, 5),
(3, 15, NULL, 1),
(4, 5, NULL, 4);
