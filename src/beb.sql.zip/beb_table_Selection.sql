
-- --------------------------------------------------------

--
-- Struttura della tabella `Selection`
--
-- Creazione: Mar 04, 2023 alle 14:13
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Selection`;
CREATE TABLE IF NOT EXISTS `Selection` (
  `selection_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` int UNSIGNED NOT NULL,
  `room_id` int UNSIGNED DEFAULT NULL,
  `service_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`selection_id`,`request_id`),
  KEY `request_id` (`request_id`),
  KEY `room_id` (`room_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Selection`
--

INSERT DELAYED IGNORE INTO `Selection` (`selection_id`, `request_id`, `room_id`, `service_id`) VALUES
(1, 1, 1, NULL),
(2, 2, 2, NULL),
(3, 3, 3, NULL),
(4, 4, 4, NULL),
(5, 5, 5, NULL);
