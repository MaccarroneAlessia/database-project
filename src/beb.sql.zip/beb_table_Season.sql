
-- --------------------------------------------------------

--
-- Struttura della tabella `Season`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Season`;
CREATE TABLE IF NOT EXISTS `Season` (
  `season_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `month_` smallint UNSIGNED DEFAULT NULL,
  `rate` float UNSIGNED DEFAULT '0',
  PRIMARY KEY (`season_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Season`
--

INSERT DELAYED IGNORE INTO `Season` (`season_id`, `month_`, `rate`) VALUES
(1, 1, 10),
(2, 2, 15),
(3, 3, 5),
(4, 4, 10),
(5, 5, 10),
(6, 6, 20),
(7, 7, 30),
(8, 8, 40),
(9, 9, 30),
(10, 10, 20),
(11, 11, 10),
(12, 12, 40);
