
-- --------------------------------------------------------

--
-- Struttura della tabella `Review`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Review`;
CREATE TABLE IF NOT EXISTS `Review` (
  `customer_id` int UNSIGNED NOT NULL,
  `room_id` int UNSIGNED NOT NULL,
  `num_stars` smallint UNSIGNED NOT NULL,
  `comment` text,
  PRIMARY KEY (`customer_id`,`room_id`,`num_stars`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Review`
--

INSERT DELAYED IGNORE INTO `Review` (`customer_id`, `room_id`, `num_stars`, `comment`) VALUES
(1, 1, 4, NULL),
(2, 2, 5, NULL),
(3, 3, 3, NULL);
