
-- --------------------------------------------------------

--
-- Struttura della tabella `Customer`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Customer`;
CREATE TABLE IF NOT EXISTS `Customer` (
  `customer_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(35) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(40) NOT NULL,
  `banking_count` varchar(16) DEFAULT NULL,
  `num_card` int UNSIGNED DEFAULT NULL,
  `points` int UNSIGNED DEFAULT '0',
  `start_date_card` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Customer`
--

INSERT DELAYED IGNORE INTO `Customer` (`customer_id`, `first_name`, `last_name`, `phone`, `email`, `banking_count`, `num_card`, `points`, `start_date_card`, `end_date`) VALUES
(1, 'Alessia', 'Maccarrone', '1234567890', 'maccalessia@gmail.com', NULL, 1, 0, '2023-03-04 14:14:08', NULL),
(2, 'Mario', 'Bianchi', '1234567890', 'mario@gmail.com', NULL, 1, 0, '2023-03-04 14:14:08', NULL),
(3, 'Vittoria', 'Rossi', '1234567890', 'rossi@gmail.com', NULL, 1, 0, '2023-03-04 14:14:08', NULL),
(4, 'Salvo', 'Catania', '1234567890', 'salvo@gmail.com', NULL, NULL, 0, '2023-03-04 14:14:08', NULL),
(5, 'Gioele', 'Federico', '1234567890', 'fede@gmail.com', NULL, NULL, 0, '2023-03-04 14:14:08', NULL);
