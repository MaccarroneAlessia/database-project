
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `Contact`
--
ALTER TABLE `Contact`
  ADD CONSTRAINT `Contact_ibfk_1` FOREIGN KEY (`home_id`) REFERENCES `Home` (`home_id`);

--
-- Limiti per la tabella `Invoice`
--
ALTER TABLE `Invoice`
  ADD CONSTRAINT `Invoice_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`customer_id`),
  ADD CONSTRAINT `Invoice_ibfk_2` FOREIGN KEY (`report_id`) REFERENCES `Report` (`report_id`),
  ADD CONSTRAINT `Invoice_ibfk_3` FOREIGN KEY (`reservation_id`) REFERENCES `Reservation` (`reservation_id`);

--
-- Limiti per la tabella `PrivateService`
--
ALTER TABLE `PrivateService`
  ADD CONSTRAINT `PrivateService_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `Room` (`room_id`);

--
-- Limiti per la tabella `Report`
--
ALTER TABLE `Report`
  ADD CONSTRAINT `Report_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`CF`);

--
-- Limiti per la tabella `Request`
--
ALTER TABLE `Request`
  ADD CONSTRAINT `Request_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `Reservation` (`reservation_id`),
  ADD CONSTRAINT `Request_ibfk_2` FOREIGN KEY (`sojourn_id`) REFERENCES `Sojourn` (`sojourn_id`),
  ADD CONSTRAINT `Request_ibfk_3` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`CF`);

--
-- Limiti per la tabella `Reservation`
--
ALTER TABLE `Reservation`
  ADD CONSTRAINT `Reservation_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`customer_id`);

--
-- Limiti per la tabella `Review`
--
ALTER TABLE `Review`
  ADD CONSTRAINT `Review_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`customer_id`),
  ADD CONSTRAINT `Review_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `Room` (`room_id`);

--
-- Limiti per la tabella `Room`
--
ALTER TABLE `Room`
  ADD CONSTRAINT `Room_ibfk_1` FOREIGN KEY (`home_id`) REFERENCES `Home` (`home_id`);

--
-- Limiti per la tabella `Selection`
--
ALTER TABLE `Selection`
  ADD CONSTRAINT `Selection_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `Request` (`request_id`),
  ADD CONSTRAINT `Selection_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `Room` (`room_id`),
  ADD CONSTRAINT `Selection_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `Servicing` (`service_id`);

--
-- Limiti per la tabella `Servicing`
--
ALTER TABLE `Servicing`
  ADD CONSTRAINT `Servicing_ibfk_1` FOREIGN KEY (`home_id`) REFERENCES `Home` (`home_id`);

--
-- Limiti per la tabella `Signup`
--
ALTER TABLE `Signup`
  ADD CONSTRAINT `Signup_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`customer_id`),
  ADD CONSTRAINT `Signup_ibfk_2` FOREIGN KEY (`home_id`) REFERENCES `Home` (`home_id`);

--
-- Limiti per la tabella `Sojourn`
--
ALTER TABLE `Sojourn`
  ADD CONSTRAINT `Sojourn_ibfk_1` FOREIGN KEY (`season_id`) REFERENCES `Season` (`season_id`);

--
-- Limiti per la tabella `Staff`
--
ALTER TABLE `Staff`
  ADD CONSTRAINT `Staff_ibfk_1` FOREIGN KEY (`home_id`) REFERENCES `Home` (`home_id`),
  ADD CONSTRAINT `Staff_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `Contact` (`contact_id`);
