
-- --------------------------------------------------------

--
-- Struttura della tabella `Invoice`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Invoice`;
CREATE TABLE IF NOT EXISTS `Invoice` (
  `invoice_number` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `curr_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `rate` float DEFAULT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `issuer` varchar(70) DEFAULT NULL,
  `pay_type` varchar(30) DEFAULT NULL,
  `pay_description` text,
  `customer_id` int UNSIGNED DEFAULT NULL,
  `report_id` int UNSIGNED DEFAULT NULL,
  `reservation_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `report_id` (`report_id`),
  KEY `reservation_id` (`reservation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Invoice`
--

INSERT DELAYED IGNORE INTO `Invoice` (`invoice_number`, `curr_date`, `rate`, `amount`, `issuer`, `pay_type`, `pay_description`, `customer_id`, `report_id`, `reservation_id`) VALUES
(1, '2023-03-04 14:14:08', NULL, 0, '15', 'bonifico', NULL, 1, NULL, 1),
(2, '2023-03-04 14:14:08', NULL, 0, '15', 'bonifico', NULL, 2, NULL, 2),
(3, '2023-03-04 14:14:08', NULL, 0, '15', 'bonifico', NULL, 3, NULL, 3),
(4, '2023-03-04 14:14:08', NULL, 0, '15', 'bonifico', NULL, 4, NULL, 4),
(5, '2023-03-04 14:14:08', NULL, 0, '15', 'bonifico', NULL, 5, NULL, 5);
