
-- --------------------------------------------------------

--
-- Struttura della tabella `Staff`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Staff`;
CREATE TABLE IF NOT EXISTS `Staff` (
  `CF` varchar(16) NOT NULL,
  `last_name` varchar(35) DEFAULT NULL,
  `first_name` varchar(35) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `hours_worked` int UNSIGNED DEFAULT '0',
  `salary` int UNSIGNED DEFAULT '0',
  `role_staff` varchar(40) DEFAULT NULL,
  `home_id` int UNSIGNED DEFAULT NULL,
  `contact_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`CF`),
  UNIQUE KEY `CF` (`CF`),
  KEY `home_id` (`home_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Staff`
--

INSERT DELAYED IGNORE INTO `Staff` (`CF`, `last_name`, `first_name`, `phone`, `email`, `hours_worked`, `salary`, `role_staff`, `home_id`, `contact_id`) VALUES
('adcsewe', NULL, NULL, NULL, NULL, 40, 3000, 'gestore', 1, 2),
('asccdfver', NULL, NULL, NULL, NULL, 80, 2000, 'addetto della pulizia', 1, 1),
('awjlefefbe', NULL, NULL, NULL, NULL, 40, 3000, 'gestore', 3, 1),
('bge6ye5bngds', NULL, NULL, NULL, NULL, 40, 3000, 'gestore', 3, 4),
('cebfkhrfk', NULL, NULL, NULL, NULL, 80, 2000, 'addetto della pulizia', 2, 4),
('erfvewwv', NULL, NULL, NULL, NULL, 80, 2000, 'addetto della pulizia', 2, 3),
('ffvsrtgsthb', NULL, NULL, NULL, NULL, 50, 1500, 'segretario', 1, 4),
('mqwert02h67f789x', NULL, NULL, NULL, NULL, 50, 1500, 'segretario', 1, 1),
('rvbtrnyjge', NULL, NULL, NULL, NULL, 50, 1500, 'segretario', 3, 4),
('vererwfa', NULL, NULL, NULL, NULL, 50, 1500, 'segretario', 2, 2),
('vrtgtrbhteb', NULL, NULL, NULL, NULL, 80, 2000, 'addetto della pulizia', 3, 4),
('vtevberthr', NULL, NULL, NULL, NULL, 40, 3000, 'gestore', 2, 3);
