
-- --------------------------------------------------------

--
-- Struttura della tabella `Sojourn`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Sojourn`;
CREATE TABLE IF NOT EXISTS `Sojourn` (
  `sojourn_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `date_in` date NOT NULL,
  `date_fin` date NOT NULL,
  `season_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`sojourn_id`),
  KEY `season_id` (`season_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Sojourn`
--

INSERT DELAYED IGNORE INTO `Sojourn` (`sojourn_id`, `date_in`, `date_fin`, `season_id`) VALUES
(1, '2022-09-20', '2022-09-25', NULL),
(2, '2022-10-02', '2022-10-07', NULL),
(3, '2022-10-15', '2022-10-22', NULL),
(4, '2022-11-25', '2022-11-30', NULL),
(5, '2022-12-20', '2022-12-25', NULL);
