
-- --------------------------------------------------------

--
-- Struttura della tabella `Contact`
--
-- Creazione: Mar 04, 2023 alle 14:09
-- Ultimo aggiornamento: Mar 04, 2023 alle 14:14
--

DROP TABLE IF EXISTS `Contact`;
CREATE TABLE IF NOT EXISTS `Contact` (
  `contact_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_staff` varchar(30) DEFAULT NULL,
  `office` varchar(30) DEFAULT NULL,
  `phone` varchar(13) NOT NULL,
  `home_id` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`contact_id`),
  KEY `home_id` (`home_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `Contact`
--

INSERT DELAYED IGNORE INTO `Contact` (`contact_id`, `role_staff`, `office`, `phone`, `home_id`) VALUES
(1, 'assistenza', 'via Amantea 33', '1234567890', 1),
(2, 'prenotazioni', 'via Amantea 33', '1234567890', 1),
(3, 'assistenza', 'via Tropea 33', '1234567890', 2),
(4, 'assistenza', 'via Tropea 33', '1234567890', 3);
